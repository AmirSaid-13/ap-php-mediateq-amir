[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/zXRCWoKP)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=12862408)
# Mediateq web version de départ
Installation du projet :

Copier le code dans un repertoire de votre serveur.

Executer le script sql/mediateq.sql pour créer la bdd, l'utilisateur de l'application, les tables et les données de départ.

Verifier la config d'acces bdd dans infoBDD.inc.php
