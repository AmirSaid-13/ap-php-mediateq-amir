<?php

$titre = "Mon Dossier - Catalogue - Mediateq";

// appel du script de vue qui permet de gerer l'affichage des donnees
include "$racine/vue/header.php";
include "$racine/vue/v_monDossier.php";
include "$racine/vue/footer.php";
?>