<?php

$titre = "Mes Emprunts - EnCours - Mediateq";

// appel du script de vue qui permet de gerer l'affichage des donnees
include "$racine/vue/header.php";
include "$racine/vue/v_emprunt.php";
include "$racine/vue/footer.php";
?>