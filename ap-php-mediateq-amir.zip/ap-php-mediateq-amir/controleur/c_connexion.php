<?php

$message ="";
$vue ="$racine/vue/v_form_connexion.php";

if (isset($_POST['NumAbonnement']) && isset($_POST['password'])) {

    $numeroAbonnement = $_POST['NumAbonnement'];
    $motDePasse = $_POST['password'];

    $ConnexionManager= new ConnexionManager();
    $Connexion = $ConnexionManager->login($numeroAbonnement, $motDePasse);
    if ($Connexion) {
        $vue ="$racine/vue/v_conf_connexion.php";
        $titre = "vous etes bien connecter";


    } else {

        $vue ="$racine/vue/v_form_connexion.php";
        $message = "erreur de connexion";
        $titre = "connectez vous";

    }
}

// appel du script de vue qui permet de gerer l'affichage des donnees
include "$racine/vue/header.php";
include $vue;
include "$racine/vue/footer.php";

?>