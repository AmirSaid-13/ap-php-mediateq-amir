<?php

$titre = "Recherche Avancée - Catalogue - Mediateq";



// appel du script de vue qui permet de gerer l'affichage des donnees
include "$racine/vue/header.php";
echo "A développer...";
include "$racine/vue/footer.php";
?>

