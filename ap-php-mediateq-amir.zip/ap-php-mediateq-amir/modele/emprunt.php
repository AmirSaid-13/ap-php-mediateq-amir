<?php

class Emprunt
{
    private int $idAbonne;
    private int $idDocument;
    private int $numero;
    private DateTime $dateDebut;
    private DateTime $dateFin;
    private bool $rendu;
    private bool $prologeable;

    /**
     * construteur de la classe Emprunt
     *
     * @param integer $unId
     * @param int $unIdDocument
     * @param int $unNumero
     * @param DateTime $uneDateDebut
     * @param DateTime $uneDateFin
     * @param bool $rendu
     * @param bool $prologeable
     */
    public function __construct(int $unId, int $unIdDocument, int $unNumero, DateTime $uneDateDebut, DateTime $uneDateFin, bool $rendu, bool $prologeable)
    {
        $this->idAbonne = $unId;
        $this->idDocument = $unIdDocument;
        $this->numero = $unNumero;
        $this->dateDebut = $uneDateDebut;
        $this->dateFin = $uneDateFin;
        $this->rendu = $rendu;
        $this->prologeable = $prologeable;
    }

    public function getIdAbonne(): int
    {
        return $this->idAbonne;
    }

    public function getIdDocument(): int
    {
        return $this->idDocument;
    }

    public function getNumero(): int
    {
        return $this->numero;
    }

    public function getDateDebut(): DateTime
    {
        return $this->dateDebut;
    }

    public function getDateFin(): DateTime
    {
        return $this->dateFin;
    }

    public function getRendu(): bool
    {
        return $this->rendu;
    }

    public function getPrologeable(): bool
    {
        return $this->prologeable;
    }
}
