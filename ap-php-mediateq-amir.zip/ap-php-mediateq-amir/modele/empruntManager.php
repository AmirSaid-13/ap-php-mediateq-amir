<?php
require_once 'emprunt.php';
require_once 'document.php'; // Assurez-vous d'avoir une classe Document

class empruntManager extends Manager
{
    
    public function getList() : array
    {

        $etatManager = new EtatManager(); // Création d'un objet manager d'état
        $lesEtats = $etatManager->getList(); // chargement du dictionnaire des états
        
        $q = $this->getPDO()->prepare('SELECT * FROM emprunt');
        $q->execute();
        $e1 = $q->fetchAll(PDO::FETCH_ASSOC);
        
        $lesEmprunts = array();
        
        
        foreach($e1 as $unEmprunt)
        {
            $lesEmprunts[$unEmprunt['id']] = new Revue($unEmprunt['id'], $unEmprunt['titre'], $unEmprunt['empruntable']);
            // on récupère la collection de parutions de cette revue
            $q2 = $this->getPDO()->prepare("SELECT * FROM emprunt JOIN abonne ON emprunt.numero_abonnement = abonne.numero_abonnement JOIN document ON document.id = emprunt.idDocument JOIN public ON public.id = document.idPublic WHERE adresse_mail = (SELECT adresse_mail FROM abonne WHERE adresse_mail = '" . $idAbonne . "' )");
            $q2->bindParam(':id',  $unEmprunt['id'], PDO::PARAM_INT);
            $q2->execute();
            $e2 = $q2->fetchAll(PDO::FETCH_ASSOC);
            $lesNumeros = array();
            foreach($e2 as $unEmprunt)
            {

                $lesEmprunts[$unEmprunt['id']] = new Emprunt($unEmprunt['idDocument'], $unEmprunt['numero'], $unEmprunt['numero_abonnement'], $unEmprunt['dateDebut'], $unEmprunt['dateFin'],$unEmprunt['rendu'], $unEmprunt['prolongeable']);
            }
            // on instancie la collection d'exemplaires dans l'objet livre
            $lesEmprunts[$unEmprunt['id']]->setlesNumeros($lesNumeros);

        }
        return $lesEmprunts;
    }


 
// class empruntManager extends Manager
// {
//     private $prets; // Tableau pour stocker les prêts
 
//     public function __construct()
//     {
//         $this->prets = array();
//     }
 
//     // Méthode pour récupérer la liste des prêts en cours
//     public function getPretsEnCours()
//     {
//         return $this->prets;
//     }
 
 
//     public function getPretsUtilisateur(): array
//     {
 
//         $idAbonne = $_SESSION['abonne'];
 
//         $sql = "SELECT * FROM emprunt JOIN abonne ON emprunt.numero_abonnement = abonne.numero_abonnement JOIN document ON document.id = emprunt.idDocument JOIN public ON public.id = document.idPublic WHERE adresse_mail = (SELECT adresse_mail FROM abonne WHERE adresse_mail = '" . $idAbonne . "' )";
 
//         $stmt = $this->getPDO()->prepare($sql);
//         $stmt->execute();
//         $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
 
//         $pretsUtilisateur = array();
//         foreach ($result as $row) {
//             $document = new Document($row['idDocument'], $row['titre'], $row['image'], $row['commandeEnCours'], $row['idPublic']);
 
 
//             $emprunt = new Emprunt($row['idAbonne'], $row['idDocument'], $row['dateDebut'], $row['dateFin'], $row['prolongeable'], $document);
//             $pretsUtilisateur[] = $pret;
//         }
 
//         return $pretsUtilisateur;
//     }
//     public function estExpire($dateFin)
//     {
//         $aujourdhui = new DateTime();
//         $dateFin = new DateTime($dateFin);
 
//         return $dateFin < $aujourdhui;
//     }
 
//     public function prolongerPret($idDocument, $nouvelleDateFin)
//     {
//         $sql = "UPDATE emprunt SET dateFin = :nouvelleDateFin WHERE idDocument = :idDocument";
//         $stmt = $this->getPDO()->prepare($sql);
//         $stmt->bindParam(':nouvelleDateFin', $nouvelleDateFin, PDO::PARAM_STR);
//         $stmt->bindParam(':idDocument', $idDocument, PDO::PARAM_INT);
//         $stmt->execute();
//     }
 
   
// }

}

?>