<?php

// class   HistoriqueManager extends Manager
// {
//     /**
//      * Renvoie un tableau associatif contenant l'ensemble des objets Livre
//      *
//      * @return array
//      */
//     public function getList() : array
//     {
        
//     } 