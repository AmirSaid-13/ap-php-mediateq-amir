<?php

 class Abonne
 {
     private $numeroAbonnement;
     private $nom;
     private $prenom;
     private $mdp;
     private $dateFinAbonnement;
 
     public function __construct($numeroAbonnement, $nom, $prenom, $mdp, $date_fin_abonnement)
     {
         $this->numeroAbonnement = $numeroAbonnement;
         $this->nom = $nom;
         $this->prenom = $prenom;
         $this->mdp = $mdp;
         $this->dateFinAbonnement = $date_fin_abonnement;
     }
 
     // Getters
 
     public function getNumeroAbonnement()
     {
         return $this->numeroAbonnement;
     }
 
     public function getNom()
     {
         return $this->nom;
     }
 
     public function getPrenom()
     {
         return $this->prenom;
     }
 
     public function getMdp()
     {
         return $this->mdp;
     }
 
     public function getDateFinAbonnement()
     {
         return $this->dateFinAbonnement;
     }
 }