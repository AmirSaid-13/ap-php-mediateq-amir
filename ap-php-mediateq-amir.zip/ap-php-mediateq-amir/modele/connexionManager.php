<?php

class ConnexionManager extends Manager
{
    /**
     * Renvoie un tableau associatif contenant l'ensemble des objets TypePublic
     *
     * @return array
     */

    public function login(string $numero_abonnement, string $mdp ) : bool {
        if(!isset($_SESSION)) {
            session_start();
        }
        $toto = new AbonneManager();
        $abo = $toto->getAbonneeByNumeroAbonnement($numero_abonnement);
        if ($abo != null){
            $mdpBD = $abo->getMdp();

            // remplacer le == par comparaiso hash avec password_verify()
            if (password_verify($mdp, $mdpBD)) {
                $_SESSION["abo"] = $abo->getNumeroAbonnement();
                $_SESSION["mdp"] = $mdp;
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function isLoggedOn() : bool {
        if (!isset($_SESSION)) {
            session_start();
        }
        $ret = false;

        if (isset($_SESSION["abo"]))
        {
            $abonneManager = new AbonneManager();
            $util = $abonneManager->getAbonneeByNumeroAbonnement($_SESSION["abo"]);
            if(($util->getNumeroAbonnement() == $_SESSION["abo"]) && (password_verify($_SESSION["mdp"], $util->getMdp())))
            {
                $ret = true;
            }
        }
        return $ret;
    }

    public function logout() : void {
        if (!isset($_SESSION)) {
            session_start();
        }
        unset($_SESSION["abo"], $_SESSION["mdp"]);
        session_destroy();
    }
}
?>
