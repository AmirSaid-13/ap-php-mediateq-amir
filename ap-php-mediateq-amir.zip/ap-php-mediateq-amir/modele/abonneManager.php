<?php

class AbonneManager extends Manager
{
    // ...

    // Fonction pour récupérer un abonné par numéro d'abonnement depuis la base de données

    public function getAbonneeByNumeroAbonnement(string $numero_abonnement) : mixed
    {
        $q = $this->getPDO()->prepare('SELECT * from abonne WHERE numero_abonnement = :numero_abonnement ');
        $q->bindValue(':numero_abonnement', $numero_abonnement, PDO::PARAM_STR);
        $q->execute();
        $ligne = $q->fetch(PDO::FETCH_ASSOC);
        if ($ligne != null){
            $unAbonne = new Abonne($ligne['numero_abonnement'], $ligne['nom'], $ligne['prenom'], $ligne['mdp'], $ligne['date_fin_abonnement']);
        return $unAbonne;
        } else {
            return null;
        }

    }

}