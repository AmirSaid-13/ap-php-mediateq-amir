<html>
<head>
    <title>Search History</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Vous avez 4 recherches dans votre historique.</h1>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Titre</th>
                <th>Date</th>
                <th>Dernière recherche</th>
                <th>CE résultats</th>
                <th>Sauvegarder</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>carnet apothicaire</td>
                <td>25/11/2021</td>
                <td>CE</td>
                <td>résultats</td>
                <td>Sauvegarder</td>
            </tr>
            <tr>
                <td>2</td>
                <td>affaire snowden</td>
                <td>25/11/2021</td>
                <td>-</td>
                <td>-</td>
                <td>Sauvegardé</td>
            </tr>
            <tr>
                <td>3</td>
                <td>promised neverland 17</td>
                <td>03/03/2021</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>
        </tbody>
    </table>
    <div style="text-align: center;">
        <button>SAUVEGARDER L'HISTORIQUE</button>
        <button>SUPPRIMER L'HISTORIQUE</button>
    </div>
</body>
</html>