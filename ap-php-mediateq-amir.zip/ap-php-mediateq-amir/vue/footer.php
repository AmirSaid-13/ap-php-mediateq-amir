                <!-- Footer -->
                <footer class="text-center text-lg-start bg-light text-muted fixed-bottom">
                    <!-- Copyright -->
                    <div class="text-center p-1" style="background-color: rgba(0, 0, 0, 0.05);">
                        <a href="https://creativecommons.org/licenses/by-nc-sa/3.0/fr/" target="_blank"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Cc-by-nc-sa_euro_icon.svg/180px-Cc-by-nc-sa_euro_icon.svg.png" height='40px'></a>  TAB 2022&copy;  | <a href="./?action=mentions">Mentions légales</a>
                    </div>
                <!-- Copyright -->
                </footer>
                <!-- Footer -->


            </div>
        </div>


    </body>
</html>