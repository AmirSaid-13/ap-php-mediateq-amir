<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon dossier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .tableau {
            width: 100%;
            border-collapse: collapse;
        }
        .tableau th, .tableau td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        .tableau th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Mon dossier</h1>
    <h2>Prêts et prolongations</h2>

    <table class="tableau">
        <tr>
            <th>Image</th>
            <th>Titre</th>
            <th>Numero de document</th>
            <th>Type de document</th>
            <th>Date De Debut</th>
            <th>Date de Fin</th>
        </tr>
    </table>
</body>
</html>