<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accary Abonnement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        h2 {
            color: #007bff;
            margin-bottom: 20px;
        }

        .row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .label {
            font-weight: bold;
            margin-right: 5px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Accary Abonnement</h2>
        <div class="row"> <span class="label">Numéro:</span> <span>270</span> </div>
        <div class="row"> <span class="label">Expire le:</span> <span>27/09/2022</span> </div>
        <div class="row"> <span class="label">Emprunts en cours:</span> <span>0</span> </div>
        <div class="row"> <span class="label">Réservations:</span> <span>1</span> </div>
        <div class="row"> <span class="label">Frais:</span> <span>0,00 €</span> </div>
    </div>
</body>

</html>