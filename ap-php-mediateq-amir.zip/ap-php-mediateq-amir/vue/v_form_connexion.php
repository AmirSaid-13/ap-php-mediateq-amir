
<div class="login-container">
    <h2>Connexion</h2>
    <form class="login-form" method="post" action="index.php?action=connexion">
        <input type="text" name="NumAbonnement" placeholder="Numéro d'abonnement" required>
        <input type="password" name="password" placeholder="Mot de passe" required>
        <button type="submit">Se connecter</button>
    </form>
</div>
<?php
if ($message != "") {
    echo $message;
}?>
